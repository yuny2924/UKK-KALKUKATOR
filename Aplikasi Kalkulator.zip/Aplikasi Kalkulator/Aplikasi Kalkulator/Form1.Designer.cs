﻿namespace Aplikasi_Kalkulator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtdis1 = new System.Windows.Forms.TextBox();
            this.txtdis2 = new System.Windows.Forms.TextBox();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnx = new System.Windows.Forms.Button();
            this.btnbagi = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btntambah = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btnkurang = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnkoma = new System.Windows.Forms.Button();
            this.btnsd = new System.Windows.Forms.Button();
            this.btnhps = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtdis1
            // 
            this.txtdis1.Font = new System.Drawing.Font("Segoe UI", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtdis1.Location = new System.Drawing.Point(63, 58);
            this.txtdis1.Name = "txtdis1";
            this.txtdis1.ReadOnly = true;
            this.txtdis1.Size = new System.Drawing.Size(548, 78);
            this.txtdis1.TabIndex = 0;
            this.txtdis1.Text = "0";
            this.txtdis1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtdis1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtdis2
            // 
            this.txtdis2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdis2.Location = new System.Drawing.Point(63, 58);
            this.txtdis2.Name = "txtdis2";
            this.txtdis2.ReadOnly = true;
            this.txtdis2.Size = new System.Drawing.Size(121, 32);
            this.txtdis2.TabIndex = 1;
            this.txtdis2.Text = "0";
            this.txtdis2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtdis2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn7.Location = new System.Drawing.Point(63, 186);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(121, 56);
            this.btn7.TabIndex = 2;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn8.Location = new System.Drawing.Point(206, 186);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(121, 56);
            this.btn8.TabIndex = 3;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn9.Location = new System.Drawing.Point(351, 186);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(121, 56);
            this.btn9.TabIndex = 4;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btnx
            // 
            this.btnx.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnx.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnx.Location = new System.Drawing.Point(490, 186);
            this.btnx.Name = "btnx";
            this.btnx.Size = new System.Drawing.Size(121, 56);
            this.btnx.TabIndex = 5;
            this.btnx.Text = "X";
            this.btnx.UseVisualStyleBackColor = false;
            this.btnx.Click += new System.EventHandler(this.btnx_Click);
            // 
            // btnbagi
            // 
            this.btnbagi.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnbagi.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnbagi.Location = new System.Drawing.Point(490, 295);
            this.btnbagi.Name = "btnbagi";
            this.btnbagi.Size = new System.Drawing.Size(121, 56);
            this.btnbagi.TabIndex = 9;
            this.btnbagi.Text = "/";
            this.btnbagi.UseVisualStyleBackColor = false;
            this.btnbagi.Click += new System.EventHandler(this.btnbagi_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn6.Location = new System.Drawing.Point(351, 295);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(121, 56);
            this.btn6.TabIndex = 8;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn5.Location = new System.Drawing.Point(206, 295);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(121, 56);
            this.btn5.TabIndex = 7;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn4.Location = new System.Drawing.Point(63, 295);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(121, 56);
            this.btn4.TabIndex = 6;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btntambah
            // 
            this.btntambah.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btntambah.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btntambah.Location = new System.Drawing.Point(490, 401);
            this.btntambah.Name = "btntambah";
            this.btntambah.Size = new System.Drawing.Size(121, 56);
            this.btntambah.TabIndex = 13;
            this.btntambah.Text = "+";
            this.btntambah.UseVisualStyleBackColor = false;
            this.btntambah.Click += new System.EventHandler(this.button9_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn3.Location = new System.Drawing.Point(351, 401);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(121, 56);
            this.btn3.TabIndex = 12;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn2.Location = new System.Drawing.Point(206, 401);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(121, 56);
            this.btn2.TabIndex = 11;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn1.Location = new System.Drawing.Point(63, 401);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(121, 56);
            this.btn1.TabIndex = 10;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btnkurang
            // 
            this.btnkurang.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnkurang.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnkurang.Location = new System.Drawing.Point(490, 502);
            this.btnkurang.Name = "btnkurang";
            this.btnkurang.Size = new System.Drawing.Size(121, 56);
            this.btnkurang.TabIndex = 17;
            this.btnkurang.Text = "-";
            this.btnkurang.UseVisualStyleBackColor = false;
            this.btnkurang.Click += new System.EventHandler(this.btnkurang_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnclear.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnclear.Location = new System.Drawing.Point(351, 502);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(121, 56);
            this.btnclear.TabIndex = 16;
            this.btnclear.Text = "C";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn0.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn0.Location = new System.Drawing.Point(206, 502);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(121, 56);
            this.btn0.TabIndex = 15;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btnkoma
            // 
            this.btnkoma.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnkoma.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnkoma.Location = new System.Drawing.Point(63, 502);
            this.btnkoma.Name = "btnkoma";
            this.btnkoma.Size = new System.Drawing.Size(121, 56);
            this.btnkoma.TabIndex = 14;
            this.btnkoma.Text = ",";
            this.btnkoma.UseVisualStyleBackColor = false;
            this.btnkoma.Click += new System.EventHandler(this.btnkoma_Click);
            // 
            // btnsd
            // 
            this.btnsd.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnsd.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnsd.Location = new System.Drawing.Point(63, 585);
            this.btnsd.Name = "btnsd";
            this.btnsd.Size = new System.Drawing.Size(409, 58);
            this.btnsd.TabIndex = 18;
            this.btnsd.Text = "=";
            this.btnsd.UseVisualStyleBackColor = false;
            this.btnsd.Click += new System.EventHandler(this.btnsd_Click);
            // 
            // btnhps
            // 
            this.btnhps.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnhps.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnhps.Location = new System.Drawing.Point(490, 585);
            this.btnhps.Name = "btnhps";
            this.btnhps.Size = new System.Drawing.Size(121, 58);
            this.btnhps.TabIndex = 19;
            this.btnhps.Text = "<";
            this.btnhps.UseVisualStyleBackColor = false;
            this.btnhps.Click += new System.EventHandler(this.btnhps_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(684, 750);
            this.Controls.Add(this.btnhps);
            this.Controls.Add(this.btnsd);
            this.Controls.Add(this.btnkurang);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btnkoma);
            this.Controls.Add(this.btntambah);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btnbagi);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btnx);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.txtdis2);
            this.Controls.Add(this.txtdis1);
            this.Name = "Form1";
            this.Text = "Kalkulator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtdis1;
        private TextBox txtdis2;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btnx;
        private Button btnbagi;
        private Button btn6;
        private Button btn5;
        private Button btn4;
        private Button btntambah;
        private Button btn3;
        private Button btn2;
        private Button btn1;
        private Button btnkurang;
        private Button btnclear;
        private Button btn0;
        private Button btnkoma;
        private Button btnsd;
        private Button btnhps;
    }
}